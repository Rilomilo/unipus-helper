let a_ls=document.getElementsByTagName("a");
let ul=document.getElementsByTagName("ul")[0];
let image_ls=document.getElementsByTagName("img");
let timer;
ul.style.width=image_ls.length*500+"px";

for(let i=0;i<5;i++){
    a_ls[i].index=i;
    a_ls[i].onclick=function(){
        let start=Number(getComputedStyle(ul,null).left.slice(0,-2));
        let end=-this.index*500;
        changeName(this.index);
        move(ul,start,end);
    }
}

function move(obj,start,end,callback){
    clearInterval(timer);
    timer=setInterval(function(){
        let x=Number(getComputedStyle(obj,null).left.slice(0,-2));
        if(x==end){
            clearInterval(timer);
            callback && callback();
            return;
        }
        obj.style.left=x-(start-end)/100+"px";
    },10)
}

function changeName(n){
    for(let i=0;i<5;i++){
        a_ls[i].className="deflaut";
    }
    a_ls[n].className="visiting";
}